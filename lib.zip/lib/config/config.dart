import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:inet/models/alarm_type.dart';
import 'package:inet/models/channel_measure.dart';
import 'package:inet/models/logger_address.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:inet/models/logger_point.dart';

import '../models/alarm_logger.dart';

FirebaseMessaging messaging;

String viewData = "";

String username_config = "";

List<ChannelMeasure> listChannelMeasure = new List<ChannelMeasure>();

List<String> listChannelSelect = new List<String>();

List<LoggerPoint> listAddresses = new List<LoggerPoint>();

bool isConnectToSocket = false;

bool isOffline = false;

bool isGisAvailable = true;

MapController globalMapController;

String linkFeatureLayer = "";

bool flagChartClicked = false;

List<AlarmType> listAlarmType = new List<AlarmType>();

List<AlarmLogger> listAlarmLogger = new List<AlarmLogger>();