import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class Auth {
  FlutterSecureStorage storage;
  Auth() {
    storage = new FlutterSecureStorage(); // 1
  }

  void setPassword(String password) { // 1
    storage.write(key: "inetPassword", value: password); // 3
  }

  Future<String> getPassword() async { // 1
    return await storage.read(key: "inetPassword"); // 2
  }

  void setUsername(String password) { // 1
    storage.write(key: "inetUsername", value: password); // 3
  }

  Future<String> getUsername() async { // 1
    return await storage.read(key: "inetUsername"); // 2
  }

  void clearSavedDate() {
    storage.write(key: "inetPassword", value: ""); //
    storage.write(key: "inetUsername", value: ""); // 3// 3
  }
}