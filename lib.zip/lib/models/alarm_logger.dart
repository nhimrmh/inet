class AlarmLogger {
  String _loggerID;
  Map<int, String> _channelAlarm;

  String get loggerID => _loggerID;

  set loggerID(String value) {
    _loggerID = value;
  }

  Map<int, String> get channelAlarm => _channelAlarm;

  set channelAlarm(Map<int, String> value) {
    _channelAlarm = value;
  }
}