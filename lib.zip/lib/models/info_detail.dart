class InfoDetail {
  DateTime _dateTime;
  double _value;

  DateTime get dateTime => _dateTime;

  set dateTime(DateTime value) {
    _dateTime = value;
  }

  double get value => _value;

  set value(double value) {
    _value = value;
  }
}