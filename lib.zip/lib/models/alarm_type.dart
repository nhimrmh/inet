class AlarmType {
  String _id;
  String _name;
  String _color;

  String get color => _color;

  set color(String value) {
    _color = value;
  }

  String get id => _id;

  set id(String value) {
    _id = value;
  }

  String get name => _name;

  set name(String value) {
    _name = value;
  }
}