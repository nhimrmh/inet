class ChartData {
  int _timeStamp;
  double _value;

  int get timeStamp => _timeStamp;

  set timeStamp(int value) {
    _timeStamp = value;
  }

  double get value => _value;

  set value(double value) {
    _value = value;
  }
}