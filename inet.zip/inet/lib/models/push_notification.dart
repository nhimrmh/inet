class PushNotification {
  PushNotification({
    this.title,
    this.body,
  });
  String title;
  String body;
}